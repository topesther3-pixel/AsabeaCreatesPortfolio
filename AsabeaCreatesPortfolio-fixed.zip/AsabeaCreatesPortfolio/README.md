# AsabeaCreates Portfolio

Portfolio site for **Esther Asabea** — AI Creative Technologist, Storyteller and Product Builder.

## Positioning
A premium editorial portfolio focused on the intersection of AI, storytelling and practical product thinking.

## Sections
- Meet the Creator
- About
- Selected Work
- Creative Process
- AI Toolkit
- Storytelling
- Product Thinking
- Why I Create
- Contact

## Featured work
MAMA YIE, WAKONTA AI, SMARTCLEAN, ASABEA FIT, PASSION PHUSION and civic storytelling/NCCE work.

## Toolkit
ChatGPT, Claude, Gemini, Google AI Studio, Grok, Canva, Runway, Higgsfield, Suno, CapCut and Adobe Creative Tools.

## Tech
Semantic HTML, modern CSS and lightweight vanilla JavaScript. No framework or unnecessary dependency.

## Hero media
The hero uses `assets/video/32808.mp4` with autoplay, loop, muted and playsinline behavior. The video is intentionally presented as a quiet moving portrait rather than a talking avatar.

## Run locally
Open `index.html` in a local static server. For example:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.
